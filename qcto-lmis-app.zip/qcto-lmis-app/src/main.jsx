import React from "react";
import ReactDOM from "react-dom/client";
import App from "./App.jsx";
import "./index.css";

/*
 * App.jsx was built as a Claude.ai artifact, which provides a built-in
 * `window.storage` API (get/set/delete/list) for saving data. That API
 * doesn't exist outside Claude.ai, so this shim reproduces the same
 * interface using the browser's localStorage. Nothing in App.jsx needs
 * to change — it just keeps calling window.storage as before.
 *
 * Because this uses localStorage, each visitor's browser has its own
 * separate copy of the data (learners, qualifications, users, etc).
 * There's no shared server, so changes made on one device won't show
 * up on another. That's fine for a demo — for a real shared multi-user
 * deployment you'd want to swap this shim out for calls to a real
 * backend/database instead.
 */
function createLocalStorageShim() {
  const prefix = "qcto_lmis::";
  return {
    async get(key) {
      const raw = window.localStorage.getItem(prefix + key);
      if (raw === null) throw new Error(`No value stored for "${key}"`);
      return { key, value: raw };
    },
    async set(key, value) {
      window.localStorage.setItem(prefix + key, value);
      return { key, value };
    },
    async delete(key) {
      window.localStorage.removeItem(prefix + key);
      return { key, deleted: true };
    },
    async list(keyPrefix = "") {
      const keys = Object.keys(window.localStorage)
        .filter((k) => k.startsWith(prefix + keyPrefix))
        .map((k) => k.slice(prefix.length));
      return { keys };
    },
  };
}

if (!window.storage) {
  window.storage = createLocalStorageShim();
}

ReactDOM.createRoot(document.getElementById("root")).render(
  <React.StrictMode>
    <App />
  </React.StrictMode>
);
