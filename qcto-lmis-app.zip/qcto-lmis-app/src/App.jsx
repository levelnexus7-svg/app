import { useState, useEffect, useMemo } from "react";
import {
  LayoutDashboard, Users, BookOpen, FileBarChart, Plus, X, Search,
  ChevronRight, ChevronLeft, AlertTriangle, Download, Trash2, Pencil,
  GraduationCap, ShieldCheck, Clock, CheckCircle2, RotateCcw,
  LogOut, KeyRound, UserCog, Eye, EyeOff,
} from "lucide-react";
import {
  BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer,
  PieChart, Pie, Cell, Legend,
} from "recharts";

/* ---------------------------------------------------------------------- *
 * TOKENS — color, type, and the K/P/W triad system                       *
 * ---------------------------------------------------------------------- */
const C = {
  ink: "#1B2A4A",
  inkSoft: "#3C4A68",
  paper: "#F6F7F3",
  paperRaised: "#FFFFFF",
  line: "#DBDCD3",
  lineSoft: "#E9EAE3",
  brass: "#A97C2F",
  brassSoft: "#F1E4C9",
  competent: "#2F7A4F",
  competentSoft: "#E1EFE4",
  progress: "#C48A1F",
  progressSoft: "#F5E9CF",
  nyc: "#B23B3B",
  nycSoft: "#F5DEDC",
  neutral: "#8B8D85",
  neutralSoft: "#EBEBE6",
};

const MODULE_TYPES = {
  K: { label: "Knowledge", short: "K", color: "#2E5B8A" },
  P: { label: "Practical Skill", short: "P", color: "#A97C2F" },
  W: { label: "Work-Based Experience", short: "W", color: "#2F7A4F" },
};

const MODULE_STATUS = [
  "Not Started",
  "In Progress",
  "Evidence Submitted",
  "Assessed - Competent",
  "Assessed - Not Yet Competent",
];
const MODERATION_STATUS = ["Not Yet Moderated", "Confirmed", "Not Confirmed - Review Required"];
const RACE_OPTIONS = ["African", "Coloured", "Indian", "White", "Other", "Prefer not to say"];
const GENDER_OPTIONS = ["Male", "Female", "Other", "Prefer not to say"];
const FUNDING_OPTIONS = ["SETA Discretionary Grant", "SETA Mandatory Grant", "Employer Funded", "Self-Funded", "Other"];
const PROGRAMME_TYPES = ["Learnership", "Apprenticeship", "Skills Programme", "Occupational Certificate (Full Qualification)"];
const ENROLMENT_STATUSES = ["Active", "On Hold", "Withdrawn", "Internally Complete", "EISA Registered", "Certified"];
const ROLES = ["Admin", "Facilitator/Assessor", "Moderator", "Learner"];

const FONT_IMPORT =
  "@import url('https://fonts.googleapis.com/css2?family=Source+Serif+4:opsz,wght@8..60,500;8..60,600;8..60,700&family=IBM+Plex+Sans:wght@400;500;600;700&family=IBM+Plex+Mono:wght@400;500;600&display=swap');";
const F = {
  display: "'Source Serif 4', Georgia, 'Times New Roman', serif",
  body: "'IBM Plex Sans', system-ui, -apple-system, 'Segoe UI', Roboto, sans-serif",
  mono: "'IBM Plex Mono', 'SFMono-Regular', Consolas, monospace",
};

/* ---------------------------------------------------------------------- *
 * UTILITIES                                                              *
 * ---------------------------------------------------------------------- */
const uid = (p) => `${p}_${Date.now().toString(36)}${Math.random().toString(36).slice(2, 7)}`;

function formatDate(d) {
  if (!d) return "—";
  const dt = new Date(d + "T00:00:00");
  if (isNaN(dt.getTime())) return d;
  return dt.toLocaleDateString("en-ZA", { year: "numeric", month: "short", day: "numeric" });
}
const todayStr = () => new Date().toISOString().slice(0, 10);

function csvEscape(v) {
  const s = v === null || v === undefined ? "" : String(v);
  if (/[",\n]/.test(s)) return `"${s.replace(/"/g, '""')}"`;
  return s;
}
function downloadCsv(filename, rows) {
  const content = rows.map((r) => r.map(csvEscape).join(",")).join("\r\n");
  const blob = new Blob([content], { type: "text/csv;charset=utf-8;" });
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = filename;
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  URL.revokeObjectURL(url);
}

function progressFor(progressList, enrolmentId, moduleId) {
  return progressList.find((p) => p.enrolmentId === enrolmentId && p.moduleId === moduleId) || null;
}

function computeReadiness(qualification, enrolment, progressList) {
  if (!qualification) return { ready: false, byType: {}, doneCount: 0, total: 0 };
  const modules = qualification.modules;
  const byType = { K: { done: 0, total: 0 }, P: { done: 0, total: 0 }, W: { done: 0, total: 0 } };
  let doneCount = 0;
  modules.forEach((m) => {
    byType[m.type].total += 1;
    const p = progressFor(progressList, enrolment.id, m.id);
    const done = p && p.status === "Assessed - Competent" && p.moderationStatus === "Confirmed";
    if (done) {
      byType[m.type].done += 1;
      doneCount += 1;
    }
  });
  return { ready: modules.length > 0 && doneCount === modules.length, byType, doneCount, total: modules.length };
}

function permissions(role) {
  return {
    editLearnerRecord: role === "Admin" || role === "Facilitator/Assessor",
    deleteLearner: role === "Admin",
    addEnrolment: role === "Admin" || role === "Facilitator/Assessor",
    editAssessment: role === "Admin" || role === "Facilitator/Assessor",
    editModeration: role === "Admin" || role === "Moderator",
    editEisaAndCert: role === "Admin",
    editQualifications: role === "Admin",
    resetData: role === "Admin",
    manageUsers: role === "Admin",
  };
}

/* ---------------------------------------------------------------------- *
 * SEED DATA — clearly-labelled sample content, meant to be replaced      *
 * ---------------------------------------------------------------------- */
function seedQualifications() {
  return [
    {
      id: "qual_electrician",
      title: "Occupational Certificate: Electrician",
      qctoId: "121101000 (sample)",
      nqfLevel: 4,
      saqaId: "SAMPLE-0001",
      modules: [
        { id: "m_elec_k1", code: "121101000-KM-01", title: "Occupational Health and Safety in the Electrical Environment", type: "K", credits: 8 },
        { id: "m_elec_k2", code: "121101000-KM-02", title: "Electrical Principles and Theory", type: "K", credits: 12 },
        { id: "m_elec_p1", code: "121101000-PM-01", title: "Install and Maintain Electrical Wiring Systems", type: "P", credits: 15 },
        { id: "m_elec_p2", code: "121101000-PM-02", title: "Test and Fault-Find Electrical Installations", type: "P", credits: 10 },
        { id: "m_elec_w1", code: "121101000-WM-01", title: "Workplace Experience: Electrical Installations", type: "W", credits: 20 },
      ],
    },
    {
      id: "qual_cookery",
      title: "Occupational Certificate: Professional Cookery Practitioner",
      qctoId: "334101000 (sample)",
      nqfLevel: 5,
      saqaId: "SAMPLE-0002",
      modules: [
        { id: "m_cook_k1", code: "334101000-KM-01", title: "Food Safety and Kitchen Management Theory", type: "K", credits: 6 },
        { id: "m_cook_p1", code: "334101000-PM-01", title: "Prepare and Present Menu Items", type: "P", credits: 14 },
        { id: "m_cook_p2", code: "334101000-PM-02", title: "Kitchen Operations and Costing", type: "P", credits: 8 },
        { id: "m_cook_w1", code: "334101000-WM-01", title: "Workplace Experience: Commercial Kitchen", type: "W", credits: 18 },
      ],
    },
  ];
}

function seedLearners() {
  return [
    { id: "l1", firstName: "Nomvula", lastName: "Khumalo", idNumber: "9803125800083", gender: "Female", race: "African", disability: false, contactNumber: "071 234 5678", email: "nomvula.k@example.com", highestPriorQualification: "NSC (Matric)", employer: "Thusong Electrical Services", fundingSource: "SETA Discretionary Grant", seta: "EWSETA", siteOfLearning: "Durban Campus" },
    { id: "l2", firstName: "Sipho", lastName: "Ndlovu", idNumber: "0002146800089", gender: "Male", race: "African", disability: false, contactNumber: "082 555 1122", email: "sipho.n@example.com", highestPriorQualification: "NSC (Matric)", employer: "Thusong Electrical Services", fundingSource: "SETA Discretionary Grant", seta: "EWSETA", siteOfLearning: "Durban Campus" },
    { id: "l3", firstName: "Priya", lastName: "Naidoo", idNumber: "9711080800084", gender: "Female", race: "Indian", disability: false, contactNumber: "083 987 6543", email: "priya.n@example.com", highestPriorQualification: "N3 Certificate", employer: "PowerLine Contractors", fundingSource: "Employer Funded", seta: "EWSETA", siteOfLearning: "Pinetown Site" },
    { id: "l4", firstName: "Johan", lastName: "Botha", idNumber: "9509025800088", gender: "Male", race: "White", disability: false, contactNumber: "084 111 2233", email: "johan.b@example.com", highestPriorQualification: "NSC (Matric)", employer: "PowerLine Contractors", fundingSource: "Employer Funded", seta: "EWSETA", siteOfLearning: "Pinetown Site" },
    { id: "l5", firstName: "Amahle", lastName: "Zulu", idNumber: "0104220800082", gender: "Female", race: "African", disability: true, contactNumber: "079 222 4455", email: "amahle.z@example.com", highestPriorQualification: "NSC (Matric)", employer: "The Oceanview Hotel Group", fundingSource: "SETA Discretionary Grant", seta: "CATHSSETA", siteOfLearning: "Umhlanga Kitchen" },
    { id: "l6", firstName: "Bongani", lastName: "Mahlangu", idNumber: "9906185800085", gender: "Male", race: "African", disability: false, contactNumber: "071 333 8899", email: "bongani.m@example.com", highestPriorQualification: "N4 Certificate", employer: "The Oceanview Hotel Group", fundingSource: "Self-Funded", seta: "CATHSSETA", siteOfLearning: "Umhlanga Kitchen" },
  ];
}

function seedEnrolments() {
  return [
    { id: "e1", learnerId: "l1", qualificationId: "qual_electrician", programmeType: "Learnership", cohort: "ELEC-2025-A", siteOfLearning: "Durban Campus", enrolmentDate: "2025-02-03", expectedCompletionDate: "2026-08-01", agreementNumber: "EWS/LN/2025/0114", status: "Active", aqpName: "", eisaRegistrationDate: "", eisaDate: "", eisaResult: "Pending", certificateNumber: "", certificationDate: "" },
    { id: "e2", learnerId: "l2", qualificationId: "qual_electrician", programmeType: "Learnership", cohort: "ELEC-2025-A", siteOfLearning: "Durban Campus", enrolmentDate: "2025-02-03", expectedCompletionDate: "2026-08-01", agreementNumber: "EWS/LN/2025/0115", status: "Active", aqpName: "", eisaRegistrationDate: "", eisaDate: "", eisaResult: "Pending", certificateNumber: "", certificationDate: "" },
    { id: "e3", learnerId: "l3", qualificationId: "qual_electrician", programmeType: "Apprenticeship", cohort: "ELEC-2024-C", siteOfLearning: "Pinetown Site", enrolmentDate: "2024-06-10", expectedCompletionDate: "2026-06-10", agreementNumber: "EWS/AP/2024/0033", status: "EISA Registered", aqpName: "EWSETA Assessment Quality Partner", eisaRegistrationDate: "2026-06-15", eisaDate: "2026-08-20", eisaResult: "Pending", certificateNumber: "", certificationDate: "" },
    { id: "e4", learnerId: "l4", qualificationId: "qual_electrician", programmeType: "Apprenticeship", cohort: "ELEC-2024-C", siteOfLearning: "Pinetown Site", enrolmentDate: "2024-06-10", expectedCompletionDate: "2026-01-10", agreementNumber: "EWS/AP/2024/0034", status: "Certified", aqpName: "EWSETA Assessment Quality Partner", eisaRegistrationDate: "2025-11-01", eisaDate: "2025-12-05", eisaResult: "Competent", certificateNumber: "QCTO-EL-2025-8842", certificationDate: "2026-01-20" },
    { id: "e5", learnerId: "l5", qualificationId: "qual_cookery", programmeType: "Learnership", cohort: "COOK-2025-B", siteOfLearning: "Umhlanga Kitchen", enrolmentDate: "2025-03-17", expectedCompletionDate: "2026-09-17", agreementNumber: "CAT/LN/2025/0207", status: "Active", aqpName: "", eisaRegistrationDate: "", eisaDate: "", eisaResult: "Pending", certificateNumber: "", certificationDate: "" },
    { id: "e6", learnerId: "l6", qualificationId: "qual_cookery", programmeType: "Skills Programme", cohort: "COOK-2025-B", siteOfLearning: "Umhlanga Kitchen", enrolmentDate: "2025-03-17", expectedCompletionDate: "2025-12-17", agreementNumber: "CAT/SP/2025/0208", status: "Active", aqpName: "", eisaRegistrationDate: "", eisaDate: "", eisaResult: "Pending", certificateNumber: "", certificationDate: "" },
  ];
}

function seedProgress() {
  const rows = [];
  const push = (enrolmentId, moduleId, status, moderationStatus, extra = {}) =>
    rows.push({ id: uid("p"), enrolmentId, moduleId, status, moderationStatus, evidenceNotes: "", evidenceDate: "", assessorName: "", assessmentDate: "", moderatorName: "", moderationDate: "", loggedHours: "", ...extra });

  // l1 (e1) — early stage
  push("e1", "m_elec_k1", "Assessed - Competent", "Confirmed", { assessorName: "T. Mkhize", assessmentDate: "2025-04-02", moderatorName: "S. Reddy", moderationDate: "2025-04-10" });
  push("e1", "m_elec_k2", "In Progress", "Not Yet Moderated");
  push("e1", "m_elec_p1", "Not Started", "Not Yet Moderated");
  push("e1", "m_elec_p2", "Not Started", "Not Yet Moderated");
  push("e1", "m_elec_w1", "In Progress", "Not Yet Moderated", { loggedHours: 240 });

  // l2 (e2) — mid stage, one NYC needing attention
  push("e2", "m_elec_k1", "Assessed - Competent", "Confirmed", { assessorName: "T. Mkhize", assessmentDate: "2025-04-02", moderatorName: "S. Reddy", moderationDate: "2025-04-10" });
  push("e2", "m_elec_k2", "Assessed - Not Yet Competent", "Not Confirmed - Review Required", { assessorName: "T. Mkhize", assessmentDate: "2025-07-14", moderatorName: "S. Reddy", moderationDate: "2025-07-20" });
  push("e2", "m_elec_p1", "Evidence Submitted", "Not Yet Moderated");
  push("e2", "m_elec_p2", "Not Started", "Not Yet Moderated");
  push("e2", "m_elec_w1", "In Progress", "Not Yet Moderated", { loggedHours: 310 });

  // l3 (e3) — internally complete, EISA registered
  ["m_elec_k1", "m_elec_k2", "m_elec_p1", "m_elec_p2"].forEach((m) =>
    push("e3", m, "Assessed - Competent", "Confirmed", { assessorName: "T. Mkhize", assessmentDate: "2026-02-01", moderatorName: "S. Reddy", moderationDate: "2026-02-08" })
  );
  push("e3", "m_elec_w1", "Assessed - Competent", "Confirmed", { assessorName: "T. Mkhize", assessmentDate: "2026-02-01", moderatorName: "S. Reddy", moderationDate: "2026-02-08", loggedHours: 720 });

  // l4 (e4) — certified, all complete
  ["m_elec_k1", "m_elec_k2", "m_elec_p1", "m_elec_p2", "m_elec_w1"].forEach((m) =>
    push("e4", m, "Assessed - Competent", "Confirmed", { assessorName: "T. Mkhize", assessmentDate: "2025-09-01", moderatorName: "S. Reddy", moderationDate: "2025-09-10", loggedHours: m === "m_elec_w1" ? 760 : "" })
  );

  // l5 (e5) — cookery, mixed
  push("e5", "m_cook_k1", "Assessed - Competent", "Confirmed", { assessorName: "L. Pillay", assessmentDate: "2025-05-12", moderatorName: "K. Dlamini", moderationDate: "2025-05-18" });
  push("e5", "m_cook_p1", "In Progress", "Not Yet Moderated");
  push("e5", "m_cook_p2", "Not Started", "Not Yet Moderated");
  push("e5", "m_cook_w1", "In Progress", "Not Yet Moderated", { loggedHours: 180 });

  // l6 (e6) — cookery, early
  push("e6", "m_cook_k1", "In Progress", "Not Yet Moderated");
  push("e6", "m_cook_p1", "Not Started", "Not Yet Moderated");
  push("e6", "m_cook_p2", "Not Started", "Not Yet Moderated");
  push("e6", "m_cook_w1", "Not Started", "Not Yet Moderated", { loggedHours: 0 });

  return rows;
}

function seedUsers() {
  return [
    { id: "u_admin1", username: "admin", password: "Admin@123", role: "Admin", displayName: "Programme Admin", learnerId: null },
    { id: "u_assessor1", username: "t.mkhize", password: "Assessor@123", role: "Facilitator/Assessor", displayName: "T. Mkhize", learnerId: null },
    { id: "u_assessor2", username: "l.pillay", password: "Assessor@123", role: "Facilitator/Assessor", displayName: "L. Pillay", learnerId: null },
    { id: "u_moderator1", username: "s.reddy", password: "Moderator@123", role: "Moderator", displayName: "S. Reddy", learnerId: null },
    { id: "u_moderator2", username: "k.dlamini", password: "Moderator@123", role: "Moderator", displayName: "K. Dlamini", learnerId: null },
    { id: "u_l1", username: "nomvula.khumalo", password: "Learner@123", role: "Learner", displayName: "Nomvula Khumalo", learnerId: "l1" },
    { id: "u_l2", username: "sipho.ndlovu", password: "Learner@123", role: "Learner", displayName: "Sipho Ndlovu", learnerId: "l2" },
    { id: "u_l3", username: "priya.naidoo", password: "Learner@123", role: "Learner", displayName: "Priya Naidoo", learnerId: "l3" },
    { id: "u_l4", username: "johan.botha", password: "Learner@123", role: "Learner", displayName: "Johan Botha", learnerId: "l4" },
    { id: "u_l5", username: "amahle.zulu", password: "Learner@123", role: "Learner", displayName: "Amahle Zulu", learnerId: "l5" },
    { id: "u_l6", username: "bongani.mahlangu", password: "Learner@123", role: "Learner", displayName: "Bongani Mahlangu", learnerId: "l6" },
  ];
}

function findUser(users, username, password) {
  const u = (username || "").trim().toLowerCase();
  return users.find((x) => x.username.toLowerCase() === u && x.password === password) || null;
}

/* ---------------------------------------------------------------------- *
 * SMALL UI PRIMITIVES                                                    *
 * ---------------------------------------------------------------------- */
function Badge({ children, bg, fg }) {
  return (
    <span
      className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-xs font-medium whitespace-nowrap"
      style={{ backgroundColor: bg, color: fg }}
    >
      {children}
    </span>
  );
}

function statusColors(status) {
  if (status === "Assessed - Competent") return { bg: C.competentSoft, fg: C.competent };
  if (status === "Assessed - Not Yet Competent") return { bg: C.nycSoft, fg: C.nyc };
  if (status === "Not Started") return { bg: C.neutralSoft, fg: C.neutral };
  return { bg: C.progressSoft, fg: C.progress };
}

function moderationColors(status) {
  if (status === "Confirmed") return { bg: C.competentSoft, fg: C.competent };
  if (status === "Not Confirmed - Review Required") return { bg: C.nycSoft, fg: C.nyc };
  return { bg: C.neutralSoft, fg: C.neutral };
}

function StatusBadge({ status }) {
  const c = statusColors(status);
  return <Badge bg={c.bg} fg={c.fg}>{status}</Badge>;
}
function ModerationBadge({ status }) {
  const c = moderationColors(status);
  return <Badge bg={c.bg} fg={c.fg}>{status}</Badge>;
}

// The signature element: a compact three-segment chip showing live K/P/W completion.
function TriadChip({ byType, size = "md" }) {
  const dim = size === "sm" ? 18 : 22;
  const segStyle = (type) => {
    const t = byType[type] || { done: 0, total: 0 };
    const full = t.total > 0 && t.done === t.total;
    const some = t.done > 0 && !full;
    const base = { width: dim, height: dim, borderRadius: 4, fontSize: dim * 0.5, fontFamily: F.mono, fontWeight: 600 };
    if (t.total === 0) return { ...base, backgroundColor: C.lineSoft, color: C.neutral, border: `1px solid ${C.line}` };
    if (full) return { ...base, backgroundColor: MODULE_TYPES[type].color, color: "#FFFFFF" };
    if (some) return { ...base, backgroundColor: "transparent", color: MODULE_TYPES[type].color, border: `2px solid ${MODULE_TYPES[type].color}` };
    return { ...base, backgroundColor: "transparent", color: C.neutral, border: `1px dashed ${C.line}` };
  };
  return (
    <div className="inline-flex items-center gap-1" title="Knowledge / Practical / Work-Based readiness">
      {["K", "P", "W"].map((t) => (
        <div key={t} className="flex items-center justify-center" style={segStyle(t)}>
          {t}
        </div>
      ))}
    </div>
  );
}

function StatCard({ icon: Icon, label, value, accent }) {
  return (
    <div className="rounded-lg p-4 flex items-start justify-between" style={{ backgroundColor: C.paperRaised, border: `1px solid ${C.line}` }}>
      <div>
        <div className="text-xs uppercase tracking-wide mb-1" style={{ color: C.inkSoft, fontFamily: F.body }}>{label}</div>
        <div className="text-3xl" style={{ color: C.ink, fontFamily: F.mono, fontWeight: 600 }}>{value}</div>
      </div>
      <div className="p-2 rounded-md" style={{ backgroundColor: accent + "22" }}>
        <Icon size={18} style={{ color: accent }} />
      </div>
    </div>
  );
}

function SectionLabel({ children }) {
  return (
    <div className="text-xs uppercase tracking-wider mb-2" style={{ color: C.inkSoft, fontFamily: F.body, fontWeight: 600, letterSpacing: "0.06em" }}>
      {children}
    </div>
  );
}

function Button({ children, onClick, variant = "primary", icon: Icon, size = "md", disabled, title }) {
  const pad = size === "sm" ? "px-2.5 py-1.5 text-xs" : "px-3.5 py-2 text-sm";
  const styles = {
    primary: { backgroundColor: disabled ? C.neutral : C.ink, color: "#fff", border: "none" },
    outline: { backgroundColor: "transparent", color: C.ink, border: `1px solid ${C.line}` },
    danger: { backgroundColor: "transparent", color: C.nyc, border: `1px solid ${C.nyc}55` },
    ghost: { backgroundColor: "transparent", color: C.inkSoft, border: "none" },
  };
  return (
    <button
      onClick={disabled ? undefined : onClick}
      disabled={disabled}
      title={title}
      className={`rounded-md font-medium inline-flex items-center gap-1.5 transition-colors focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 ${pad} ${disabled ? "cursor-not-allowed opacity-60" : "cursor-pointer"}`}
      style={{ ...styles[variant], fontFamily: F.body }}
    >
      {Icon ? <Icon size={size === "sm" ? 13 : 15} /> : null}
      {children}
    </button>
  );
}

function Modal({ title, onClose, children, wide }) {
  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4" style={{ backgroundColor: "#1B2A4A66" }} onMouseDown={onClose}>
      <div
        onMouseDown={(e) => e.stopPropagation()}
        className={`rounded-lg w-full ${wide ? "max-w-2xl" : "max-w-lg"} max-h-[88vh] overflow-y-auto`}
        style={{ backgroundColor: C.paperRaised, border: `1px solid ${C.line}` }}
      >
        <div className="flex items-center justify-between px-5 py-4 sticky top-0" style={{ backgroundColor: C.paperRaised, borderBottom: `1px solid ${C.line}` }}>
          <h3 style={{ fontFamily: F.display, color: C.ink }} className="text-lg font-semibold">{title}</h3>
          <button onClick={onClose} className="p-1 rounded hover:bg-black/5" aria-label="Close">
            <X size={18} style={{ color: C.inkSoft }} />
          </button>
        </div>
        <div className="p-5">{children}</div>
      </div>
    </div>
  );
}

function Field({ field, value, onChange }) {
  const base = "w-full rounded-md px-3 py-2 text-sm focus:outline-none focus-visible:outline focus-visible:outline-2";
  const style = { border: `1px solid ${C.line}`, fontFamily: F.body, backgroundColor: "#fff", color: C.ink };
  if (field.type === "select") {
    const opts = field.optionsMap || field.options.map((o) => ({ value: o, label: o }));
    return (
      <select className={base} style={style} value={value ?? ""} onChange={(e) => onChange(field.key, e.target.value)}>
        <option value="">Select…</option>
        {opts.map((o) => (
          <option key={o.value} value={o.value}>{o.label}</option>
        ))}
      </select>
    );
  }
  if (field.type === "textarea") {
    return <textarea className={base} style={style} rows={3} value={value ?? ""} onChange={(e) => onChange(field.key, e.target.value)} />;
  }
  if (field.type === "checkbox") {
    return (
      <div className="flex items-center h-9">
        <input type="checkbox" checked={!!value} onChange={(e) => onChange(field.key, e.target.checked)} className="h-4 w-4" />
      </div>
    );
  }
  return (
    <input
      type={field.type || "text"}
      className={base}
      style={style}
      value={value ?? ""}
      onChange={(e) => onChange(field.key, e.target.value)}
    />
  );
}

function FormGrid({ fields, state, setState, cols = 2 }) {
  const gridCls = cols === 1 ? "grid-cols-1" : "grid-cols-1 sm:grid-cols-2";
  return (
    <div className={`grid ${gridCls} gap-4`}>
      {fields.map((f) => (
        <div key={f.key} className={f.full ? "sm:col-span-2" : ""}>
          <label className="block text-xs font-medium mb-1" style={{ color: C.inkSoft, fontFamily: F.body }}>
            {f.label}{f.required ? " *" : ""}
          </label>
          <Field field={f} value={state[f.key]} onChange={(k, v) => setState((s) => ({ ...s, [k]: v }))} />
        </div>
      ))}
    </div>
  );
}

function ConfirmDialog({ message, confirmLabel, onConfirm, onCancel }) {
  return (
    <div className="fixed inset-0 z-[60] flex items-center justify-center p-4" style={{ backgroundColor: "#1B2A4A66" }} onMouseDown={onCancel}>
      <div
        onMouseDown={(e) => e.stopPropagation()}
        className="rounded-lg w-full max-w-sm p-5"
        style={{ backgroundColor: C.paperRaised, border: `1px solid ${C.line}` }}
      >
        <div className="flex items-start gap-3 mb-4">
          <AlertTriangle size={18} style={{ color: C.nyc }} className="shrink-0 mt-0.5" />
          <div className="text-sm" style={{ color: C.ink, fontFamily: F.body }}>{message}</div>
        </div>
        <div className="flex justify-end gap-2">
          <Button variant="outline" onClick={onCancel}>Cancel</Button>
          <Button variant="danger" onClick={onConfirm}>{confirmLabel || "Confirm"}</Button>
        </div>
      </div>
    </div>
  );
}

function EmptyState({ icon: Icon, title, body }) {
  return (
    <div className="flex flex-col items-center justify-center py-16 text-center">
      <Icon size={28} style={{ color: C.neutral }} className="mb-3" />
      <div style={{ fontFamily: F.display, color: C.ink }} className="text-base font-semibold mb-1">{title}</div>
      <div style={{ color: C.inkSoft, fontFamily: F.body }} className="text-sm max-w-sm">{body}</div>
    </div>
  );
}

/* ---------------------------------------------------------------------- *
 * DASHBOARD                                                              *
 * ---------------------------------------------------------------------- */
function Dashboard({ learners, qualifications, enrolments, progress, showBanner, onDismissBanner, goLearner }) {
  const readiness = useMemo(
    () => enrolments.map((e) => ({ e, r: computeReadiness(qualifications.find((q) => q.id === e.qualificationId), e, progress) })),
    [enrolments, qualifications, progress]
  );
  const eisaReady = readiness.filter(({ e, r }) => r.ready && e.status !== "Certified").length;
  const certified = enrolments.filter((e) => e.status === "Certified").length;
  const active = enrolments.filter((e) => e.status !== "Withdrawn" && e.status !== "Certified").length;

  const byQual = qualifications.map((q) => ({
    name: q.title.replace("Occupational Certificate: ", ""),
    learners: enrolments.filter((e) => e.qualificationId === q.id).length,
  }));

  const statusCounts = ENROLMENT_STATUSES.map((s) => ({ name: s, value: enrolments.filter((e) => e.status === s).length })).filter((s) => s.value > 0);
  const pieColors = [C.ink, C.brass, C.progress, C.competent, "#2E5B8A", C.nyc];

  const overdue = enrolments.filter((e) => e.expectedCompletionDate && e.expectedCompletionDate < todayStr() && e.status !== "Certified" && e.status !== "Withdrawn");
  const needsReview = progress.filter((p) => p.moderationStatus === "Not Confirmed - Review Required");

  return (
    <div>
      {showBanner && (
        <div className="mb-5 rounded-lg px-4 py-3 flex items-start justify-between gap-3" style={{ backgroundColor: C.brassSoft, border: `1px solid ${C.brass}55` }}>
          <div className="text-sm" style={{ color: C.ink, fontFamily: F.body }}>
            <strong>This is sample data</strong> — two example qualifications and six example learners, so you can see how records, progress, and EISA readiness connect. Edit or clear it from the Reports screen once you're ready to enter real data.
          </div>
          <button onClick={onDismissBanner} className="shrink-0 p-1 rounded hover:bg-black/5" aria-label="Dismiss">
            <X size={16} style={{ color: C.ink }} />
          </button>
        </div>
      )}

      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
        <StatCard icon={Users} label="Total Learners" value={learners.length} accent={C.ink} />
        <StatCard icon={Clock} label="Active Enrolments" value={active} accent={C.progress} />
        <StatCard icon={ShieldCheck} label="EISA-Ready" value={eisaReady} accent={C.competent} />
        <StatCard icon={GraduationCap} label="Certified" value={certified} accent={C.brass} />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4 mb-6">
        <div className="rounded-lg p-4" style={{ backgroundColor: C.paperRaised, border: `1px solid ${C.line}` }}>
          <SectionLabel>Learners per qualification</SectionLabel>
          <div style={{ width: "100%", height: 220 }}>
            <ResponsiveContainer>
              <BarChart data={byQual} margin={{ left: -20 }}>
                <CartesianGrid strokeDasharray="3 3" stroke={C.lineSoft} />
                <XAxis dataKey="name" tick={{ fontSize: 11, fontFamily: F.body, fill: C.inkSoft }} interval={0} angle={-10} textAnchor="end" height={50} />
                <YAxis allowDecimals={false} tick={{ fontSize: 11, fontFamily: F.body, fill: C.inkSoft }} />
                <Tooltip contentStyle={{ fontFamily: F.body, fontSize: 12, borderRadius: 6, border: `1px solid ${C.line}` }} />
                <Bar dataKey="learners" fill={C.ink} radius={[4, 4, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>
        <div className="rounded-lg p-4" style={{ backgroundColor: C.paperRaised, border: `1px solid ${C.line}` }}>
          <SectionLabel>Enrolment status breakdown</SectionLabel>
          <div style={{ width: "100%", height: 220 }}>
            <ResponsiveContainer>
              <PieChart>
                <Pie data={statusCounts} dataKey="value" nameKey="name" cx="50%" cy="50%" outerRadius={75} label={{ fontSize: 11, fontFamily: F.body }}>
                  {statusCounts.map((_, i) => (
                    <Cell key={i} fill={pieColors[i % pieColors.length]} />
                  ))}
                </Pie>
                <Tooltip contentStyle={{ fontFamily: F.body, fontSize: 12, borderRadius: 6, border: `1px solid ${C.line}` }} />
                <Legend wrapperStyle={{ fontSize: 11, fontFamily: F.body }} />
              </PieChart>
            </ResponsiveContainer>
          </div>
        </div>
      </div>

      <div className="rounded-lg p-4" style={{ backgroundColor: C.paperRaised, border: `1px solid ${C.line}` }}>
        <SectionLabel>Needs attention</SectionLabel>
        {overdue.length === 0 && needsReview.length === 0 ? (
          <div className="text-sm py-4" style={{ color: C.inkSoft, fontFamily: F.body }}>Nothing flagged right now.</div>
        ) : (
          <div className="divide-y" style={{ borderColor: C.lineSoft }}>
            {overdue.map((e) => {
              const l = learners.find((x) => x.id === e.learnerId);
              if (!l) return null;
              return (
                <button key={e.id} onClick={() => goLearner(l.id)} className="w-full flex items-center gap-3 py-2.5 text-left hover:bg-black/[0.02] rounded px-1">
                  <AlertTriangle size={15} style={{ color: C.nyc }} className="shrink-0" />
                  <span className="text-sm flex-1" style={{ fontFamily: F.body, color: C.ink }}>
                    <strong>{l.firstName} {l.lastName}</strong> — past expected completion ({formatDate(e.expectedCompletionDate)}), still {e.status.toLowerCase()}
                  </span>
                  <ChevronRight size={15} style={{ color: C.neutral }} />
                </button>
              );
            })}
            {needsReview.map((p) => {
              const e = enrolments.find((x) => x.id === p.enrolmentId);
              const l = e && learners.find((x) => x.id === e.learnerId);
              if (!l) return null;
              return (
                <button key={p.id} onClick={() => goLearner(l.id)} className="w-full flex items-center gap-3 py-2.5 text-left hover:bg-black/[0.02] rounded px-1">
                  <AlertTriangle size={15} style={{ color: C.progress }} className="shrink-0" />
                  <span className="text-sm flex-1" style={{ fontFamily: F.body, color: C.ink }}>
                    <strong>{l.firstName} {l.lastName}</strong> — a module assessment was not confirmed by the moderator and needs review
                  </span>
                  <ChevronRight size={15} style={{ color: C.neutral }} />
                </button>
              );
            })}
          </div>
        )}
      </div>
    </div>
  );
}

/* ---------------------------------------------------------------------- *
 * LEARNERS LIST                                                          *
 * ---------------------------------------------------------------------- */
function LearnersScreen({ learners, qualifications, enrolments, progress, perms, onOpen, onAdd, restrictToLearnerId }) {
  const [q, setQ] = useState("");
  const [qualFilter, setQualFilter] = useState("");
  const [statusFilter, setStatusFilter] = useState("");

  const visibleLearners = restrictToLearnerId ? learners.filter((l) => l.id === restrictToLearnerId) : learners;

  const rows = visibleLearners
    .map((l) => {
      const ens = enrolments.filter((e) => e.learnerId === l.id);
      return { l, ens };
    })
    .filter(({ l }) => {
      const text = `${l.firstName} ${l.lastName} ${l.idNumber}`.toLowerCase();
      if (q && !text.includes(q.toLowerCase())) return false;
      return true;
    })
    .filter(({ ens }) => (qualFilter ? ens.some((e) => e.qualificationId === qualFilter) : true))
    .filter(({ ens }) => (statusFilter ? ens.some((e) => e.status === statusFilter) : true));

  return (
    <div>
      <div className="flex flex-col sm:flex-row gap-3 mb-4 items-start sm:items-center justify-between">
        <div className="flex flex-col sm:flex-row gap-2 w-full sm:w-auto">
          <div className="relative">
            <Search size={14} className="absolute left-2.5 top-1/2 -translate-y-1/2" style={{ color: C.neutral }} />
            <input
              value={q}
              onChange={(e) => setQ(e.target.value)}
              placeholder="Search name or ID number"
              className="pl-8 pr-3 py-2 rounded-md text-sm w-full sm:w-56"
              style={{ border: `1px solid ${C.line}`, fontFamily: F.body }}
            />
          </div>
          {!restrictToLearnerId && (
            <>
              <select value={qualFilter} onChange={(e) => setQualFilter(e.target.value)} className="px-2.5 py-2 rounded-md text-sm" style={{ border: `1px solid ${C.line}`, fontFamily: F.body }}>
                <option value="">All qualifications</option>
                {qualifications.map((qq) => (
                  <option key={qq.id} value={qq.id}>{qq.title}</option>
                ))}
              </select>
              <select value={statusFilter} onChange={(e) => setStatusFilter(e.target.value)} className="px-2.5 py-2 rounded-md text-sm" style={{ border: `1px solid ${C.line}`, fontFamily: F.body }}>
                <option value="">All statuses</option>
                {ENROLMENT_STATUSES.map((s) => (
                  <option key={s} value={s}>{s}</option>
                ))}
              </select>
            </>
          )}
        </div>
        {perms.editLearnerRecord && !restrictToLearnerId && (
          <Button icon={Plus} onClick={onAdd}>Add learner</Button>
        )}
      </div>

      {rows.length === 0 ? (
        <EmptyState icon={Users} title="No learners match" body="Try a different search term or clear your filters." />
      ) : (
        <div className="rounded-lg overflow-hidden" style={{ border: `1px solid ${C.line}`, backgroundColor: C.paperRaised }}>
          <table className="w-full text-sm" style={{ fontFamily: F.body }}>
            <thead>
              <tr style={{ backgroundColor: C.paper, borderBottom: `1px solid ${C.line}` }}>
                <th className="text-left px-4 py-2.5 font-medium" style={{ color: C.inkSoft }}>Learner</th>
                <th className="text-left px-4 py-2.5 font-medium" style={{ color: C.inkSoft }}>ID number</th>
                <th className="text-left px-4 py-2.5 font-medium" style={{ color: C.inkSoft }}>Qualification / cohort</th>
                <th className="text-left px-4 py-2.5 font-medium" style={{ color: C.inkSoft }}>K/P/W</th>
                <th className="text-left px-4 py-2.5 font-medium" style={{ color: C.inkSoft }}>Status</th>
                <th className="px-4 py-2.5"></th>
              </tr>
            </thead>
            <tbody>
              {rows.map(({ l, ens }) => (
                <tr key={l.id} onClick={() => onOpen(l.id)} className="cursor-pointer hover:bg-black/[0.02]" style={{ borderBottom: `1px solid ${C.lineSoft}` }}>
                  <td className="px-4 py-3" style={{ color: C.ink, fontWeight: 500 }}>{l.firstName} {l.lastName}</td>
                  <td className="px-4 py-3" style={{ color: C.inkSoft, fontFamily: F.mono, fontSize: 12.5 }}>{l.idNumber}</td>
                  <td className="px-4 py-3" style={{ color: C.inkSoft }}>
                    {ens.length === 0 ? "Not enrolled" : ens.map((e) => qualifications.find((qq) => qq.id === e.qualificationId)?.title.replace("Occupational Certificate: ", "")).join(", ")}
                  </td>
                  <td className="px-4 py-3">
                    {ens[0] ? <TriadChip size="sm" byType={computeReadiness(qualifications.find((qq) => qq.id === ens[0].qualificationId), ens[0], progress).byType} /> : "—"}
                  </td>
                  <td className="px-4 py-3">{ens[0] ? <Badge bg={C.neutralSoft} fg={C.inkSoft}>{ens[0].status}</Badge> : "—"}</td>
                  <td className="px-4 py-3 text-right"><ChevronRight size={15} style={{ color: C.neutral }} /></td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}

/* ---------------------------------------------------------------------- *
 * LEARNER PROFILE                                                        *
 * ---------------------------------------------------------------------- */
function LearnerProfile({ learner, qualifications, enrolments, progress, perms, onBack, onEditLearner, onDeleteLearner, onAddEnrolment, onEditEnrolment, onEditProgress }) {
  const myEnrolments = enrolments.filter((e) => e.learnerId === learner.id);
  const demo = [
    ["Gender", learner.gender],
    ["Race", learner.race],
    ["Disability", learner.disability ? "Yes" : "No"],
    ["Contact", learner.contactNumber],
    ["Email", learner.email],
    ["Prior qualification", learner.highestPriorQualification],
    ["Employer", learner.employer || "—"],
    ["Funding source", learner.fundingSource],
    ["SETA", learner.seta],
    ["Site of learning", learner.siteOfLearning],
  ];

  return (
    <div>
      <button onClick={onBack} className="inline-flex items-center gap-1 text-sm mb-4 hover:underline" style={{ color: C.inkSoft, fontFamily: F.body }}>
        <ChevronLeft size={15} /> Back to learners
      </button>

      <div className="rounded-lg p-5 mb-5" style={{ backgroundColor: C.paperRaised, border: `1px solid ${C.line}` }}>
        <div className="flex items-start justify-between flex-wrap gap-3">
          <div>
            <div style={{ fontFamily: F.display, color: C.ink }} className="text-2xl font-semibold">{learner.firstName} {learner.lastName}</div>
            <div style={{ fontFamily: F.mono, color: C.inkSoft }} className="text-sm mt-0.5">{learner.idNumber}</div>
          </div>
          {perms.editLearnerRecord && (
            <div className="flex gap-2">
              <Button variant="outline" size="sm" icon={Pencil} onClick={onEditLearner}>Edit</Button>
              {perms.deleteLearner && <Button variant="danger" size="sm" icon={Trash2} onClick={onDeleteLearner}>Delete</Button>}
            </div>
          )}
        </div>
        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-5 gap-x-4 gap-y-3 mt-4 pt-4" style={{ borderTop: `1px solid ${C.lineSoft}` }}>
          {demo.map(([k, v]) => (
            <div key={k}>
              <div className="text-xs" style={{ color: C.neutral, fontFamily: F.body }}>{k}</div>
              <div className="text-sm" style={{ color: C.ink, fontFamily: F.body }}>{v || "—"}</div>
            </div>
          ))}
        </div>
      </div>

      <div className="flex items-center justify-between mb-3">
        <SectionLabel>Enrolments</SectionLabel>
        {perms.addEnrolment && <Button size="sm" variant="outline" icon={Plus} onClick={onAddEnrolment}>Add enrolment</Button>}
      </div>

      {myEnrolments.length === 0 ? (
        <EmptyState icon={BookOpen} title="No enrolments yet" body="Enrol this learner into a qualification to start tracking module progress." />
      ) : (
        <div className="space-y-5">
          {myEnrolments.map((e) => (
            <EnrolmentCard
              key={e.id}
              enrolment={e}
              qualification={qualifications.find((q) => q.id === e.qualificationId)}
              progress={progress}
              perms={perms}
              onEditEnrolment={() => onEditEnrolment(e)}
              onEditProgress={(moduleId) => onEditProgress(e, moduleId)}
            />
          ))}
        </div>
      )}
    </div>
  );
}

function EnrolmentCard({ enrolment, qualification, progress, perms, onEditEnrolment, onEditProgress }) {
  if (!qualification) return null;
  const readiness = computeReadiness(qualification, enrolment, progress);
  const grouped = { K: [], P: [], W: [] };
  qualification.modules.forEach((m) => grouped[m.type].push(m));

  return (
    <div className="rounded-lg overflow-hidden" style={{ border: `1px solid ${C.line}`, backgroundColor: C.paperRaised }}>
      <div className="px-5 py-4 flex items-start justify-between flex-wrap gap-3" style={{ borderBottom: `1px solid ${C.line}`, backgroundColor: C.paper }}>
        <div>
          <div style={{ fontFamily: F.display, color: C.ink }} className="text-base font-semibold">{qualification.title}</div>
          <div className="flex flex-wrap items-center gap-x-3 gap-y-1 mt-1 text-xs" style={{ color: C.inkSoft, fontFamily: F.body }}>
            <span>NQF {qualification.nqfLevel}</span>
            <span>·</span>
            <span>{enrolment.programmeType}</span>
            <span>·</span>
            <span>Cohort {enrolment.cohort}</span>
            <span>·</span>
            <span>{enrolment.siteOfLearning}</span>
            <span>·</span>
            <span style={{ fontFamily: F.mono }}>{enrolment.agreementNumber || "no agreement no."}</span>
          </div>
        </div>
        <div className="flex items-center gap-3">
          <TriadChip byType={readiness.byType} />
          <Badge bg={C.neutralSoft} fg={C.ink}>{enrolment.status}</Badge>
          <Button size="sm" variant="ghost" icon={Pencil} onClick={onEditEnrolment}>Edit</Button>
        </div>
      </div>

      <div className="px-5 py-3" style={{ backgroundColor: readiness.ready ? C.competentSoft : C.paperRaised, borderBottom: `1px solid ${C.lineSoft}` }}>
        {readiness.ready ? (
          <div className="flex items-center gap-2 text-sm" style={{ color: C.competent, fontFamily: F.body, fontWeight: 500 }}>
            <CheckCircle2 size={15} /> All modules assessed competent and internally moderated — ready for EISA registration.
          </div>
        ) : (
          <div className="text-sm" style={{ color: C.inkSoft, fontFamily: F.body }}>
            {readiness.doneCount} of {readiness.total} modules confirmed competent
            {" — "}K {readiness.byType.K.done}/{readiness.byType.K.total}, P {readiness.byType.P.done}/{readiness.byType.P.total}, W {readiness.byType.W.done}/{readiness.byType.W.total}
          </div>
        )}
        {(enrolment.status === "EISA Registered" || enrolment.status === "Certified" || enrolment.aqpName) && (
          <div className="mt-2 pt-2 grid grid-cols-2 sm:grid-cols-4 gap-3 text-xs" style={{ borderTop: `1px solid ${C.lineSoft}`, fontFamily: F.body, color: C.inkSoft }}>
            <div><div style={{ color: C.neutral }}>AQP</div><div>{enrolment.aqpName || "—"}</div></div>
            <div><div style={{ color: C.neutral }}>EISA date</div><div>{formatDate(enrolment.eisaDate)}</div></div>
            <div><div style={{ color: C.neutral }}>EISA result</div><div>{enrolment.eisaResult}</div></div>
            <div><div style={{ color: C.neutral }}>Certificate no.</div><div style={{ fontFamily: F.mono }}>{enrolment.certificateNumber || "—"}</div></div>
          </div>
        )}
      </div>

      <div className="divide-y" style={{ borderColor: C.lineSoft }}>
        {["K", "P", "W"].map((type) =>
          grouped[type].length === 0 ? null : (
            <div key={type} className="px-5 py-3">
              <div className="flex items-center gap-2 mb-2">
                <div className="w-2 h-2 rounded-full" style={{ backgroundColor: MODULE_TYPES[type].color }} />
                <span className="text-xs font-semibold uppercase tracking-wide" style={{ color: C.inkSoft, fontFamily: F.body }}>{MODULE_TYPES[type].label}</span>
              </div>
              <div className="space-y-1.5">
                {grouped[type].map((m) => {
                  const p = progressFor(progress, enrolment.id, m.id) || { status: "Not Started", moderationStatus: "Not Yet Moderated" };
                  return (
                    <button
                      key={m.id}
                      onClick={() => onEditProgress(m.id)}
                      className="w-full flex items-center justify-between gap-3 px-2.5 py-2 rounded-md hover:bg-black/[0.02] text-left"
                    >
                      <div className="min-w-0">
                        <div className="text-sm truncate" style={{ color: C.ink, fontFamily: F.body }}>{m.title}</div>
                        <div className="text-xs" style={{ color: C.neutral, fontFamily: F.mono }}>{m.code} · {m.credits} credits</div>
                      </div>
                      <div className="flex items-center gap-2 shrink-0">
                        <StatusBadge status={p.status} />
                        <ModerationBadge status={p.moderationStatus} />
                        <Pencil size={13} style={{ color: C.neutral }} />
                      </div>
                    </button>
                  );
                })}
              </div>
            </div>
          )
        )}
      </div>
    </div>
  );
}

/* ---------------------------------------------------------------------- *
 * QUALIFICATIONS                                                         *
 * ---------------------------------------------------------------------- */
function QualificationsScreen({ qualifications, enrolments, perms, onAdd, onEdit }) {
  return (
    <div>
      <div className="flex items-center justify-between mb-4">
        <div className="text-sm" style={{ color: C.inkSoft, fontFamily: F.body }}>
          {qualifications.length} qualification{qualifications.length === 1 ? "" : "s"} configured. Module codes, credits, and NQF levels should match your accreditation exactly.
        </div>
        {perms.editQualifications && <Button icon={Plus} onClick={onAdd}>Add qualification</Button>}
      </div>
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {qualifications.map((q) => {
          const learnerCount = enrolments.filter((e) => e.qualificationId === q.id).length;
          const counts = { K: 0, P: 0, W: 0 };
          let totalCredits = 0;
          q.modules.forEach((m) => { counts[m.type] += 1; totalCredits += Number(m.credits) || 0; });
          return (
            <div key={q.id} className="rounded-lg p-4" style={{ backgroundColor: C.paperRaised, border: `1px solid ${C.line}` }}>
              <div className="flex items-start justify-between gap-2">
                <div>
                  <div style={{ fontFamily: F.display, color: C.ink }} className="text-base font-semibold">{q.title}</div>
                  <div className="text-xs mt-0.5" style={{ color: C.inkSoft, fontFamily: F.mono }}>{q.qctoId} · SAQA {q.saqaId}</div>
                </div>
                {perms.editQualifications && (
                  <button onClick={() => onEdit(q)} className="p-1.5 rounded hover:bg-black/5 shrink-0" aria-label="Edit qualification">
                    <Pencil size={14} style={{ color: C.inkSoft }} />
                  </button>
                )}
              </div>
              <div className="flex flex-wrap items-center gap-2 mt-3">
                <Badge bg={C.neutralSoft} fg={C.ink}>NQF {q.nqfLevel}</Badge>
                <Badge bg={C.neutralSoft} fg={C.ink}>{totalCredits} credits</Badge>
                <Badge bg={C.neutralSoft} fg={C.ink}>{learnerCount} learner{learnerCount === 1 ? "" : "s"}</Badge>
              </div>
              <div className="mt-4 space-y-1.5">
                {q.modules.map((m) => (
                  <div key={m.id} className="flex items-center gap-2.5 text-sm">
                    <span
                      className="w-5 h-5 rounded flex items-center justify-center text-[10px] font-semibold shrink-0"
                      style={{ backgroundColor: MODULE_TYPES[m.type].color + "22", color: MODULE_TYPES[m.type].color, fontFamily: F.mono }}
                    >
                      {m.type}
                    </span>
                    <span className="flex-1 truncate" style={{ color: C.ink, fontFamily: F.body }}>{m.title}</span>
                    <span style={{ color: C.neutral, fontFamily: F.mono }} className="text-xs shrink-0">{m.credits}cr</span>
                  </div>
                ))}
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}

function QualificationFormModal({ initial, onSave, onClose }) {
  const [state, setState] = useState(
    initial || { id: uid("qual"), title: "", qctoId: "", nqfLevel: "", saqaId: "", modules: [] }
  );

  const addModule = () => setState((s) => ({ ...s, modules: [...s.modules, { id: uid("m"), code: "", title: "", type: "K", credits: "" }] }));
  const updateModule = (idx, key, val) =>
    setState((s) => ({ ...s, modules: s.modules.map((m, i) => (i === idx ? { ...m, [key]: val } : m)) }));
  const removeModule = (idx) => setState((s) => ({ ...s, modules: s.modules.filter((_, i) => i !== idx) }));

  return (
    <Modal title={initial ? "Edit qualification" : "Add qualification"} onClose={onClose} wide>
      <FormGrid
        fields={[
          { key: "title", label: "Qualification title", required: true, full: true },
          { key: "qctoId", label: "QCTO qualification ID" },
          { key: "saqaId", label: "SAQA ID" },
          { key: "nqfLevel", label: "NQF level", type: "number" },
        ]}
        state={state}
        setState={setState}
      />

      <div className="mt-5">
        <div className="flex items-center justify-between mb-2">
          <SectionLabel>Modules (Knowledge / Practical / Work-Based)</SectionLabel>
          <Button size="sm" variant="outline" icon={Plus} onClick={addModule}>Add module</Button>
        </div>
        <div className="space-y-2">
          {state.modules.map((m, idx) => (
            <div key={m.id} className="grid grid-cols-12 gap-2 items-center rounded-md p-2" style={{ border: `1px solid ${C.lineSoft}` }}>
              <select value={m.type} onChange={(e) => updateModule(idx, "type", e.target.value)} className="col-span-2 rounded px-2 py-1.5 text-xs" style={{ border: `1px solid ${C.line}`, fontFamily: F.body }}>
                <option value="K">Knowledge</option>
                <option value="P">Practical</option>
                <option value="W">Work-Based</option>
              </select>
              <input value={m.code} onChange={(e) => updateModule(idx, "code", e.target.value)} placeholder="Module code" className="col-span-3 rounded px-2 py-1.5 text-xs" style={{ border: `1px solid ${C.line}`, fontFamily: F.mono }} />
              <input value={m.title} onChange={(e) => updateModule(idx, "title", e.target.value)} placeholder="Module title" className="col-span-5 rounded px-2 py-1.5 text-xs" style={{ border: `1px solid ${C.line}`, fontFamily: F.body }} />
              <input value={m.credits} onChange={(e) => updateModule(idx, "credits", e.target.value)} type="number" placeholder="Credits" className="col-span-1 rounded px-2 py-1.5 text-xs" style={{ border: `1px solid ${C.line}`, fontFamily: F.body }} />
              <button onClick={() => removeModule(idx)} className="col-span-1 p-1.5 rounded hover:bg-black/5 flex justify-center" aria-label="Remove module">
                <Trash2 size={13} style={{ color: C.nyc }} />
              </button>
            </div>
          ))}
          {state.modules.length === 0 && <div className="text-xs py-2" style={{ color: C.neutral, fontFamily: F.body }}>No modules yet — add at least one.</div>}
        </div>
      </div>

      <div className="flex justify-end gap-2 mt-6 pt-4" style={{ borderTop: `1px solid ${C.lineSoft}` }}>
        <Button variant="outline" onClick={onClose}>Cancel</Button>
        <Button onClick={() => { onSave(state); onClose(); }} disabled={!state.title || state.modules.length === 0}>Save qualification</Button>
      </div>
    </Modal>
  );
}

/* ---------------------------------------------------------------------- *
 * REPORTS                                                                *
 * ---------------------------------------------------------------------- */
function ReportsScreen({ learners, qualifications, enrolments, progress, perms, onReset }) {
  const exportRegister = () => {
    const rows = [["First name", "Last name", "ID number", "Gender", "Race", "Disability", "SETA", "Funding source", "Employer", "Qualification", "Programme type", "Cohort", "Status", "Enrolment date", "Expected completion"]];
    enrolments.forEach((e) => {
      const l = learners.find((x) => x.id === e.learnerId);
      const q = qualifications.find((x) => x.id === e.qualificationId);
      if (!l) return;
      rows.push([l.firstName, l.lastName, l.idNumber, l.gender, l.race, l.disability ? "Yes" : "No", l.seta, l.fundingSource, l.employer, q ? q.title : "", e.programmeType, e.cohort, e.status, e.enrolmentDate, e.expectedCompletionDate]);
    });
    downloadCsv("learner-register.csv", rows);
  };

  const exportEisaReady = () => {
    const rows = [["First name", "Last name", "ID number", "Qualification", "Cohort", "Modules complete", "Total modules", "Current status"]];
    enrolments.forEach((e) => {
      const l = learners.find((x) => x.id === e.learnerId);
      const q = qualifications.find((x) => x.id === e.qualificationId);
      if (!l || !q) return;
      const r = computeReadiness(q, e, progress);
      if (r.ready && e.status !== "Certified") rows.push([l.firstName, l.lastName, l.idNumber, q.title, e.cohort, r.doneCount, r.total, e.status]);
    });
    downloadCsv("eisa-ready-list.csv", rows);
  };

  const exportDemographics = () => {
    const rows = [["Category", "Value", "Count"]];
    const tally = (key, label) => {
      const map = {};
      learners.forEach((l) => { map[l[key]] = (map[l[key]] || 0) + 1; });
      Object.entries(map).forEach(([v, c]) => rows.push([label, v, c]));
    };
    tally("gender", "Gender");
    tally("race", "Race");
    tally("fundingSource", "Funding source");
    tally("seta", "SETA");
    rows.push(["Disability", "Yes", learners.filter((l) => l.disability).length]);
    rows.push(["Disability", "No", learners.filter((l) => !l.disability).length]);
    downloadCsv("demographics-summary.csv", rows);
  };

  const exportModuleProgress = () => {
    const rows = [["Learner", "ID number", "Qualification", "Module code", "Module title", "Type", "Status", "Assessor", "Assessment date", "Moderation status", "Moderator", "Moderation date", "Logged hours"]];
    enrolments.forEach((e) => {
      const l = learners.find((x) => x.id === e.learnerId);
      const q = qualifications.find((x) => x.id === e.qualificationId);
      if (!l || !q) return;
      q.modules.forEach((m) => {
        const p = progressFor(progress, e.id, m.id) || {};
        rows.push([`${l.firstName} ${l.lastName}`, l.idNumber, q.title, m.code, m.title, MODULE_TYPES[m.type].label, p.status || "Not Started", p.assessorName || "", p.assessmentDate || "", p.moderationStatus || "Not Yet Moderated", p.moderatorName || "", p.moderationDate || "", p.loggedHours ?? ""]);
      });
    });
    downloadCsv("module-progress.csv", rows);
  };

  const items = [
    { title: "Learner register", body: "Every learner with their enrolment, funding, and demographic details — for SETA and QCTO submissions.", action: exportRegister },
    { title: "EISA-ready list", body: "Learners who have completed and internally moderated every module, and are ready to register for EISA.", action: exportEisaReady },
    { title: "Demographics summary", body: "Gender, race, disability, funding source, and SETA breakdowns for WSP/ATR and equity reporting.", action: exportDemographics },
    { title: "Module progress", body: "Every module for every learner, with assessment and moderation status — a full audit trail.", action: exportModuleProgress },
  ];

  return (
    <div>
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 mb-6">
        {items.map((it) => (
          <div key={it.title} className="rounded-lg p-4" style={{ backgroundColor: C.paperRaised, border: `1px solid ${C.line}` }}>
            <div style={{ fontFamily: F.display, color: C.ink }} className="text-base font-semibold mb-1">{it.title}</div>
            <div className="text-sm mb-3" style={{ color: C.inkSoft, fontFamily: F.body }}>{it.body}</div>
            <Button size="sm" variant="outline" icon={Download} onClick={it.action}>Export CSV</Button>
          </div>
        ))}
      </div>

      {perms.resetData && (
        <div className="rounded-lg p-4" style={{ backgroundColor: C.paperRaised, border: `1px solid ${C.nyc}44` }}>
          <div style={{ fontFamily: F.display, color: C.ink }} className="text-base font-semibold mb-1">Reset data</div>
          <div className="text-sm mb-3" style={{ color: C.inkSoft, fontFamily: F.body }}>
            Clears every learner, qualification, enrolment, and progress record shared by this tool, and reloads the original sample data. This can't be undone.
          </div>
          <Button size="sm" variant="danger" icon={RotateCcw} onClick={onReset}>Clear all data and reload sample data</Button>
        </div>
      )}
    </div>
  );
}

/* ---------------------------------------------------------------------- *
 * LEARNER / ENROLMENT / PROGRESS FORM MODALS                             *
 * ---------------------------------------------------------------------- */
function LearnerFormModal({ initial, onSave, onClose }) {
  const [state, setState] = useState(
    initial || { id: uid("l"), firstName: "", lastName: "", idNumber: "", gender: "", race: "", disability: false, contactNumber: "", email: "", highestPriorQualification: "", employer: "", fundingSource: "", seta: "", siteOfLearning: "" }
  );
  const fields = [
    { key: "firstName", label: "First name", required: true },
    { key: "lastName", label: "Last name", required: true },
    { key: "idNumber", label: "ID number", required: true },
    { key: "gender", label: "Gender", type: "select", options: GENDER_OPTIONS },
    { key: "race", label: "Race (EE Act category, for WSP/ATR reporting)", type: "select", options: RACE_OPTIONS, full: true },
    { key: "disability", label: "Disability", type: "checkbox" },
    { key: "contactNumber", label: "Contact number" },
    { key: "email", label: "Email", type: "email" },
    { key: "highestPriorQualification", label: "Highest prior qualification" },
    { key: "employer", label: "Employer (if learnership/apprenticeship)" },
    { key: "fundingSource", label: "Funding source", type: "select", options: FUNDING_OPTIONS },
    { key: "seta", label: "SETA" },
    { key: "siteOfLearning", label: "Site of learning" },
  ];
  return (
    <Modal title={initial ? "Edit learner" : "Add learner"} onClose={onClose} wide>
      <FormGrid fields={fields} state={state} setState={setState} />
      <div className="flex justify-end gap-2 mt-6 pt-4" style={{ borderTop: `1px solid ${C.lineSoft}` }}>
        <Button variant="outline" onClick={onClose}>Cancel</Button>
        <Button onClick={() => { onSave(state); onClose(); }} disabled={!state.firstName || !state.lastName || !state.idNumber}>Save learner</Button>
      </div>
    </Modal>
  );
}

function EnrolmentFormModal({ initial, learnerId, qualifications, onSave, onClose }) {
  const [state, setState] = useState(
    initial || { id: uid("e"), learnerId, qualificationId: "", programmeType: "", cohort: "", siteOfLearning: "", enrolmentDate: todayStr(), expectedCompletionDate: "", agreementNumber: "", status: "Active", aqpName: "", eisaRegistrationDate: "", eisaDate: "", eisaResult: "Pending", certificateNumber: "", certificationDate: "" }
  );
  const fields = [
    { key: "qualificationId", label: "Qualification", type: "select", optionsMap: qualifications.map((q) => ({ value: q.id, label: q.title })), full: true },
    { key: "programmeType", label: "Programme type", type: "select", options: PROGRAMME_TYPES },
    { key: "status", label: "Status", type: "select", options: ENROLMENT_STATUSES },
    { key: "cohort", label: "Cohort" },
    { key: "siteOfLearning", label: "Site of learning" },
    { key: "enrolmentDate", label: "Enrolment date", type: "date" },
    { key: "expectedCompletionDate", label: "Expected completion date", type: "date" },
    { key: "agreementNumber", label: "Agreement number", full: true },
    { key: "aqpName", label: "AQP (assessment quality partner)", full: true },
    { key: "eisaRegistrationDate", label: "EISA registration date", type: "date" },
    { key: "eisaDate", label: "EISA date", type: "date" },
    { key: "eisaResult", label: "EISA result", type: "select", options: ["Pending", "Competent", "Not Yet Competent"] },
    { key: "certificateNumber", label: "Certificate number" },
    { key: "certificationDate", label: "Certification date", type: "date" },
  ];
  return (
    <Modal title={initial ? "Edit enrolment" : "Add enrolment"} onClose={onClose} wide>
      <FormGrid fields={fields} state={state} setState={setState} />
      <div className="flex justify-end gap-2 mt-6 pt-4" style={{ borderTop: `1px solid ${C.lineSoft}` }}>
        <Button variant="outline" onClick={onClose}>Cancel</Button>
        <Button onClick={() => { onSave(state); onClose(); }} disabled={!state.qualificationId}>Save enrolment</Button>
      </div>
    </Modal>
  );
}

function ProgressFormModal({ enrolment, module, existing, perms, onSave, onClose }) {
  const [state, setState] = useState(
    existing || { id: uid("p"), enrolmentId: enrolment.id, moduleId: module.id, status: "Not Started", evidenceNotes: "", evidenceDate: "", assessorName: "", assessmentDate: "", moderationStatus: "Not Yet Moderated", moderatorName: "", moderationDate: "", loggedHours: "" }
  );
  const assessmentFields = [
    { key: "status", label: "Assessment status", type: "select", options: MODULE_STATUS, full: true },
    { key: "evidenceDate", label: "Evidence submitted", type: "date" },
    ...(module.type === "W" ? [{ key: "loggedHours", label: "Logged workplace hours", type: "number" }] : []),
    { key: "assessorName", label: "Assessor" },
    { key: "assessmentDate", label: "Assessment date", type: "date" },
    { key: "evidenceNotes", label: "Evidence / assessment notes", type: "textarea", full: true },
  ];
  const moderationFields = [
    { key: "moderationStatus", label: "Internal moderation status", type: "select", options: MODERATION_STATUS, full: true },
    { key: "moderatorName", label: "Moderator" },
    { key: "moderationDate", label: "Moderation date", type: "date" },
  ];

  return (
    <Modal title={module.title} onClose={onClose} wide>
      <div className="text-xs mb-4" style={{ color: C.neutral, fontFamily: F.mono }}>{module.code} · {MODULE_TYPES[module.type].label} · {module.credits} credits</div>

      <fieldset disabled={!perms.editAssessment} className={!perms.editAssessment ? "opacity-60" : ""}>
        <SectionLabel>Assessment</SectionLabel>
        <FormGrid fields={assessmentFields} state={state} setState={setState} />
      </fieldset>

      <div className="mt-5 pt-5" style={{ borderTop: `1px solid ${C.lineSoft}` }}>
        <fieldset disabled={!perms.editModeration} className={!perms.editModeration ? "opacity-60" : ""}>
          <SectionLabel>Internal moderation</SectionLabel>
          <FormGrid fields={moderationFields} state={state} setState={setState} />
        </fieldset>
      </div>

      {!perms.editAssessment && !perms.editModeration && (
        <div className="text-xs mt-4" style={{ color: C.neutral, fontFamily: F.body }}>You have read-only access to this record.</div>
      )}

      <div className="flex justify-end gap-2 mt-6 pt-4" style={{ borderTop: `1px solid ${C.lineSoft}` }}>
        <Button variant="outline" onClick={onClose}>{perms.editAssessment || perms.editModeration ? "Cancel" : "Close"}</Button>
        {(perms.editAssessment || perms.editModeration) && <Button onClick={() => { onSave(state); onClose(); }}>Save</Button>}
      </div>
    </Modal>
  );
}

function LoginScreen({ users, onLogin }) {
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [showPassword, setShowPassword] = useState(false);
  const [error, setError] = useState("");
  const [showDemo, setShowDemo] = useState(false);

  const submit = (e) => {
    e.preventDefault();
    const match = findUser(users, username, password);
    if (!match) {
      setError("That username and password don't match a login on file. Check with your admin if you're not sure.");
      return;
    }
    setError("");
    onLogin(match);
  };

  const demoRows = [
    { role: "Admin", username: "admin", password: "Admin@123" },
    { role: "Facilitator/Assessor", username: "t.mkhize", password: "Assessor@123" },
    { role: "Moderator", username: "s.reddy", password: "Moderator@123" },
    { role: "Learner", username: "nomvula.khumalo", password: "Learner@123" },
  ];

  return (
    <div className="flex items-center justify-center h-full min-h-[600px] p-6" style={{ backgroundColor: C.ink, fontFamily: F.body }}>
      <style>{FONT_IMPORT}</style>
      <div className="w-full max-w-sm">
        <div className="mb-6 text-center">
          <div style={{ fontFamily: F.display, color: "#fff" }} className="text-2xl font-semibold leading-tight">QCTO LMIS</div>
          <div className="text-xs mt-1" style={{ color: "#FFFFFF99" }}>Learner Management Information System</div>
        </div>
        <form
          onSubmit={submit}
          className="rounded-lg p-5"
          style={{ backgroundColor: C.paperRaised, border: `1px solid ${C.line}` }}
        >
          <div style={{ fontFamily: F.display, color: C.ink }} className="text-lg font-semibold mb-4">Sign in</div>

          <label className="block text-xs font-medium mb-1" style={{ color: C.inkSoft }}>Username</label>
          <input
            autoFocus
            className="w-full rounded-md px-3 py-2 text-sm mb-3 focus:outline-none focus-visible:outline focus-visible:outline-2"
            style={{ border: `1px solid ${C.line}`, backgroundColor: "#fff", color: C.ink }}
            value={username}
            onChange={(e) => setUsername(e.target.value)}
            placeholder="e.g. t.mkhize"
          />

          <label className="block text-xs font-medium mb-1" style={{ color: C.inkSoft }}>Password</label>
          <div className="relative mb-1">
            <input
              type={showPassword ? "text" : "password"}
              className="w-full rounded-md px-3 py-2 pr-9 text-sm focus:outline-none focus-visible:outline focus-visible:outline-2"
              style={{ border: `1px solid ${C.line}`, backgroundColor: "#fff", color: C.ink }}
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              placeholder="••••••••"
            />
            <button
              type="button"
              onClick={() => setShowPassword((s) => !s)}
              className="absolute right-2 top-1/2 -translate-y-1/2 p-1 rounded hover:bg-black/5"
              aria-label={showPassword ? "Hide password" : "Show password"}
            >
              {showPassword ? <EyeOff size={14} style={{ color: C.inkSoft }} /> : <Eye size={14} style={{ color: C.inkSoft }} />}
            </button>
          </div>

          {error && (
            <div className="text-xs mt-2 mb-1 flex items-start gap-1.5" style={{ color: C.nyc }}>
              <AlertTriangle size={13} className="mt-0.5 shrink-0" /> {error}
            </div>
          )}

          <div className="mt-1">
            <Button size="md" onClick={submit}>Sign in</Button>
          </div>

          <div className="mt-4 pt-4" style={{ borderTop: `1px solid ${C.lineSoft}` }}>
            <button
              type="button"
              onClick={() => setShowDemo((s) => !s)}
              className="text-xs underline"
              style={{ color: C.inkSoft, fontFamily: F.body }}
            >
              {showDemo ? "Hide demo logins" : "Show demo logins"}
            </button>
            {showDemo && (
              <div className="mt-2 rounded-md p-2.5 text-xs" style={{ backgroundColor: C.paper, border: `1px solid ${C.lineSoft}`, fontFamily: F.mono, color: C.inkSoft }}>
                {demoRows.map((r) => (
                  <div key={r.username} className="flex items-center justify-between py-0.5">
                    <span>{r.role}</span>
                    <span>{r.username} / {r.password}</span>
                  </div>
                ))}
                <div className="mt-1.5 pt-1.5" style={{ borderTop: `1px solid ${C.line}`, fontFamily: F.body }}>
                  More learner logins under Users (Admin).
                </div>
              </div>
            )}
          </div>
        </form>
      </div>
    </div>
  );
}

function UsersScreen({ users, learners, currentUser, onAdd, onEdit, onDelete }) {
  return (
    <div>
      <div className="flex items-center justify-between mb-4">
        <SectionLabel>Logins ({users.length})</SectionLabel>
        <Button icon={Plus} onClick={onAdd}>Add login</Button>
      </div>
      <div className="rounded-lg overflow-hidden" style={{ border: `1px solid ${C.line}`, backgroundColor: C.paperRaised }}>
        <table className="w-full text-sm">
          <thead>
            <tr style={{ backgroundColor: C.paper, borderBottom: `1px solid ${C.line}` }}>
              {["Name", "Username", "Role", "Linked learner", ""].map((h) => (
                <th key={h} className="text-left px-4 py-2.5 text-xs uppercase tracking-wide" style={{ color: C.inkSoft, fontFamily: F.body }}>{h}</th>
              ))}
            </tr>
          </thead>
          <tbody>
            {users.map((u) => {
              const learner = u.learnerId ? learners.find((l) => l.id === u.learnerId) : null;
              return (
                <tr key={u.id} style={{ borderBottom: `1px solid ${C.lineSoft}` }}>
                  <td className="px-4 py-2.5" style={{ color: C.ink, fontFamily: F.body }}>
                    {u.displayName}
                    {u.id === currentUser.id && <span className="ml-2 text-xs" style={{ color: C.neutral }}>(you)</span>}
                  </td>
                  <td className="px-4 py-2.5" style={{ color: C.inkSoft, fontFamily: F.mono }}>{u.username}</td>
                  <td className="px-4 py-2.5"><Badge bg={C.brassSoft} fg={C.brass}>{u.role}</Badge></td>
                  <td className="px-4 py-2.5" style={{ color: C.inkSoft, fontFamily: F.body }}>{learner ? `${learner.firstName} ${learner.lastName}` : "—"}</td>
                  <td className="px-4 py-2.5">
                    <div className="flex items-center gap-1 justify-end">
                      <Button size="sm" variant="ghost" icon={Pencil} onClick={() => onEdit(u)}>Edit</Button>
                      <Button size="sm" variant="ghost" icon={Trash2} disabled={u.id === currentUser.id} title={u.id === currentUser.id ? "You can't remove your own login" : "Remove login"} onClick={() => onDelete(u)} />
                    </div>
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>
      <div className="text-xs mt-3" style={{ color: C.neutral, fontFamily: F.body }}>
        This directory of logins lives inside the app itself — there's no separate identity server behind it, so treat these as shared workspace passwords rather than personal secrets.
      </div>
    </div>
  );
}

function UserFormModal({ initial, users, learners, onSave, onClose }) {
  const [state, setState] = useState(
    initial || { id: uid("u"), displayName: "", username: "", password: "", role: "Learner", learnerId: "" }
  );
  const [error, setError] = useState("");

  const fields = [
    { key: "displayName", label: "Full name", required: true },
    { key: "username", label: "Username", required: true },
    { key: "password", label: "Password", type: "password", required: true },
    { key: "role", label: "Role", type: "select", options: ROLES },
    ...(state.role === "Learner"
      ? [{ key: "learnerId", label: "Linked learner record", type: "select", optionsMap: learners.map((l) => ({ value: l.id, label: `${l.firstName} ${l.lastName}` })), full: true }]
      : []),
  ];

  const save = () => {
    const uname = (state.username || "").trim().toLowerCase();
    const clash = users.some((u) => u.id !== state.id && u.username.toLowerCase() === uname);
    if (!state.displayName || !uname || !state.password) {
      setError("Full name, username and password are all required.");
      return;
    }
    if (clash) {
      setError("That username is already in use — pick another.");
      return;
    }
    if (state.role === "Learner" && !state.learnerId) {
      setError("Pick which learner record this login should see.");
      return;
    }
    setError("");
    onSave({ ...state, username: uname, learnerId: state.role === "Learner" ? state.learnerId : null });
    onClose();
  };

  return (
    <Modal title={initial ? "Edit login" : "Add login"} onClose={onClose}>
      <FormGrid fields={fields} state={state} setState={setState} />
      {error && (
        <div className="text-xs mt-3 flex items-start gap-1.5" style={{ color: C.nyc }}>
          <AlertTriangle size={13} className="mt-0.5 shrink-0" /> {error}
        </div>
      )}
      <div className="flex justify-end gap-2 mt-6 pt-4" style={{ borderTop: `1px solid ${C.lineSoft}` }}>
        <Button variant="outline" onClick={onClose}>Cancel</Button>
        <Button onClick={save}>Save login</Button>
      </div>
    </Modal>
  );
}

/* ---------------------------------------------------------------------- *
 * ROOT APP                                                                *
 * ---------------------------------------------------------------------- */
export default function App() {
  const [loading, setLoading] = useState(true);
  const [learners, setLearners] = useState([]);
  const [qualifications, setQualifications] = useState([]);
  const [enrolments, setEnrolments] = useState([]);
  const [progress, setProgress] = useState([]);
  const [users, setUsers] = useState([]);
  const [saveError, setSaveError] = useState("");

  const [screen, setScreen] = useState("dashboard");
  const [selectedLearnerId, setSelectedLearnerId] = useState(null);
  const [showBanner, setShowBanner] = useState(true);

  // currentUser holds the signed-in login (never persisted to shared storage —
  // it's a per-browser session, so refreshing the page signs you out again).
  const [currentUser, setCurrentUser] = useState(null);
  const role = currentUser ? currentUser.role : null;

  const [learnerModal, setLearnerModal] = useState(null); // null | {} (new) | learner (edit)
  const [qualModal, setQualModal] = useState(null);
  const [enrolModal, setEnrolModal] = useState(null); // { initial, learnerId } | null
  const [progressModal, setProgressModal] = useState(null); // { enrolment, module, existing } | null
  const [userModal, setUserModal] = useState(null); // null | {} (new) | user (edit)
  const [confirmDialog, setConfirmDialog] = useState(null); // { message, confirmLabel, onConfirm } | null

  useEffect(() => {
    let cancelled = false;
    async function load() {
      const loadKey = async (key, fallback) => {
        try {
          const res = await window.storage.get(key, true);
          if (res && res.value) return JSON.parse(res.value);
          return fallback;
        } catch (e) {
          return fallback;
        }
      };
      const [q, l, e, p, u] = await Promise.all([
        loadKey("qcto_lmis_qualifications", null),
        loadKey("qcto_lmis_learners", null),
        loadKey("qcto_lmis_enrolments", null),
        loadKey("qcto_lmis_progress", null),
        loadKey("qcto_lmis_users", null),
      ]);
      if (cancelled) return;
      const firstRun = q === null && l === null;
      const finalQ = q || seedQualifications();
      const finalL = l || seedLearners();
      const finalE = e || seedEnrolments();
      const finalP = p || seedProgress();
      const finalU = u || seedUsers();
      setQualifications(finalQ);
      setLearners(finalL);
      setEnrolments(finalE);
      setProgress(finalP);
      setUsers(finalU);
      setShowBanner(firstRun);
      setLoading(false);
      if (firstRun) {
        persist("qcto_lmis_qualifications", finalQ);
        persist("qcto_lmis_learners", finalL);
        persist("qcto_lmis_enrolments", finalE);
        persist("qcto_lmis_progress", finalP);
        persist("qcto_lmis_users", finalU);
      }
    }
    load();
    return () => { cancelled = true; };
  }, []);

  async function persist(key, data) {
    try {
      const res = await window.storage.set(key, JSON.stringify(data), true);
      if (!res) setSaveError("Your last change may not have saved. Check your connection and try again.");
      else setSaveError("");
    } catch (e) {
      setSaveError("Your last change may not have saved. Check your connection and try again.");
    }
  }

  const perms = permissions(role);
  const isLearnerRole = role === "Learner";
  const effectiveLearnerId = isLearnerRole ? currentUser.learnerId : null;

  const handleLogin = (user) => {
    setCurrentUser(user);
    setScreen(user.role === "Learner" ? "learners" : "dashboard");
    setSelectedLearnerId(null);
  };
  const handleLogout = () => {
    setCurrentUser(null);
    setScreen("dashboard");
    setSelectedLearnerId(null);
  };

  const saveUser = (u) => {
    setUsers((prev) => {
      const exists = prev.some((x) => x.id === u.id);
      const next = exists ? prev.map((x) => (x.id === u.id ? u : x)) : [...prev, u];
      persist("qcto_lmis_users", next);
      return next;
    });
  };
  const deleteUser = (u) => {
    setUsers((prev) => { const next = prev.filter((x) => x.id !== u.id); persist("qcto_lmis_users", next); return next; });
  };

  const goLearner = (id) => { setSelectedLearnerId(id); setScreen("learnerProfile"); };

  const saveLearner = (l) => {
    setLearners((prev) => {
      const exists = prev.some((x) => x.id === l.id);
      const next = exists ? prev.map((x) => (x.id === l.id ? l : x)) : [...prev, l];
      persist("qcto_lmis_learners", next);
      return next;
    });
  };
  const deleteLearner = (id) => {
    setLearners((prev) => { const next = prev.filter((x) => x.id !== id); persist("qcto_lmis_learners", next); return next; });
    setEnrolments((prev) => { const next = prev.filter((x) => x.learnerId !== id); persist("qcto_lmis_enrolments", next); return next; });
    setScreen("learners");
  };
  const saveQualification = (q) => {
    setQualifications((prev) => {
      const exists = prev.some((x) => x.id === q.id);
      const next = exists ? prev.map((x) => (x.id === q.id ? q : x)) : [...prev, q];
      persist("qcto_lmis_qualifications", next);
      return next;
    });
  };
  const saveEnrolment = (e) => {
    setEnrolments((prev) => {
      const exists = prev.some((x) => x.id === e.id);
      const next = exists ? prev.map((x) => (x.id === e.id ? e : x)) : [...prev, e];
      persist("qcto_lmis_enrolments", next);
      return next;
    });
  };
  const saveProgress = (p) => {
    setProgress((prev) => {
      const exists = prev.some((x) => x.id === p.id);
      const next = exists ? prev.map((x) => (x.id === p.id ? p : x)) : [...prev, p];
      persist("qcto_lmis_progress", next);
      return next;
    });
  };
  const resetAll = () => {
    const q = seedQualifications(), l = seedLearners(), e = seedEnrolments(), p = seedProgress();
    setQualifications(q); setLearners(l); setEnrolments(e); setProgress(p);
    persist("qcto_lmis_qualifications", q); persist("qcto_lmis_learners", l); persist("qcto_lmis_enrolments", e); persist("qcto_lmis_progress", p);
    setShowBanner(true);
    setScreen("dashboard");
  };

  const selectedLearner = learners.find((l) => l.id === selectedLearnerId) || null;

  const NAV = [
    { key: "dashboard", label: "Dashboard", icon: LayoutDashboard, hide: isLearnerRole },
    { key: "learners", label: isLearnerRole ? "My progress" : "Learners", icon: Users },
    { key: "qualifications", label: "Qualifications", icon: BookOpen, hide: isLearnerRole },
    { key: "reports", label: "Reports", icon: FileBarChart, hide: isLearnerRole },
    { key: "users", label: "Users", icon: UserCog, hide: !perms.manageUsers },
  ];

  if (loading) {
    return (
      <div className="flex items-center justify-center h-full min-h-[400px]" style={{ backgroundColor: C.paper, fontFamily: F.body }}>
        <style>{FONT_IMPORT}</style>
        <div className="text-sm" style={{ color: C.inkSoft }}>Loading learner records…</div>
      </div>
    );
  }

  if (!currentUser) {
    return <LoginScreen users={users} onLogin={handleLogin} />;
  }

  return (
    <div className="flex h-full min-h-[600px] overflow-hidden rounded-lg" style={{ backgroundColor: C.paper, fontFamily: F.body }}>
      <style>{`
        ${FONT_IMPORT}
        * { box-sizing: border-box; }
        @media (prefers-reduced-motion: reduce) { * { transition: none !important; animation: none !important; } }
      `}</style>

      {/* Sidebar */}
      <div className="w-56 shrink-0 flex flex-col" style={{ backgroundColor: C.ink }}>
        <div className="px-4 py-5" style={{ borderBottom: "1px solid #FFFFFF22" }}>
          <div style={{ fontFamily: F.display, color: "#fff" }} className="text-lg font-semibold leading-tight">QCTO LMIS</div>
          <div className="text-xs mt-0.5" style={{ color: "#FFFFFF99" }}>Learner Management Information System</div>
        </div>
        <nav className="flex-1 px-2 py-3 space-y-0.5">
          {NAV.filter((n) => !n.hide).map((n) => {
            const active = screen === n.key || (n.key === "learners" && screen === "learnerProfile");
            return (
              <button
                key={n.key}
                onClick={() => { setScreen(n.key); if (n.key !== "learnerProfile") setSelectedLearnerId(null); }}
                className="w-full flex items-center gap-2.5 px-3 py-2 rounded-md text-sm text-left focus-visible:outline focus-visible:outline-2"
                style={{
                  backgroundColor: active ? "#FFFFFF14" : "transparent",
                  color: active ? "#fff" : "#FFFFFFB0",
                  borderLeft: active ? `3px solid ${C.brass}` : "3px solid transparent",
                  fontFamily: F.body,
                  fontWeight: active ? 600 : 400,
                }}
              >
                <n.icon size={16} />
                {n.label}
              </button>
            );
          })}
        </nav>
        <div className="px-3 py-4" style={{ borderTop: "1px solid #FFFFFF22" }}>
          <div className="text-xs mb-0.5" style={{ color: "#FFFFFF80" }}>Signed in as</div>
          <div className="text-sm mb-0.5 truncate" style={{ color: "#fff", fontFamily: F.body, fontWeight: 600 }}>{currentUser.displayName}</div>
          <div className="text-xs mb-2.5" style={{ color: "#FFFFFF80" }}>{role}</div>
          <button
            onClick={handleLogout}
            className="w-full flex items-center justify-center gap-1.5 rounded-md px-2 py-1.5 text-xs"
            style={{ backgroundColor: "#FFFFFF14", color: "#fff", border: "1px solid #FFFFFF33", fontFamily: F.body }}
          >
            <LogOut size={13} /> Sign out
          </button>
        </div>
      </div>

      {/* Main */}
      <div className="flex-1 flex flex-col min-w-0">
        <div className="px-6 py-4 flex items-center justify-between" style={{ borderBottom: `1px solid ${C.line}`, backgroundColor: C.paperRaised }}>
          <div style={{ fontFamily: F.display, color: C.ink }} className="text-lg font-semibold">
            {screen === "dashboard" && "Dashboard"}
            {screen === "learners" && (isLearnerRole ? "My progress" : "Learners")}
            {screen === "learnerProfile" && "Learner profile"}
            {screen === "qualifications" && "Qualifications"}
            {screen === "reports" && "Reports"}
            {screen === "users" && "Users"}
          </div>
          <Badge bg={C.brassSoft} fg={C.brass}>{role}</Badge>
        </div>

        {saveError && (
          <div className="px-6 py-2 text-xs flex items-center gap-2" style={{ backgroundColor: C.nycSoft, color: C.nyc, fontFamily: F.body }}>
            <AlertTriangle size={13} /> {saveError}
          </div>
        )}

        <div className="flex-1 overflow-y-auto p-6">
          {isLearnerRole && !learners.some((l) => l.id === effectiveLearnerId) ? (
            <EmptyState icon={Users} title="No learner record linked" body="Your login isn't linked to a learner record yet. Ask your admin to link it under Users." />
          ) : screen === "dashboard" ? (
            <Dashboard
              learners={learners}
              qualifications={qualifications}
              enrolments={enrolments}
              progress={progress}
              showBanner={showBanner}
              onDismissBanner={() => setShowBanner(false)}
              goLearner={goLearner}
            />
          ) : screen === "learners" ? (
            <LearnersScreen
              learners={learners}
              qualifications={qualifications}
              enrolments={enrolments}
              progress={progress}
              perms={perms}
              onOpen={goLearner}
              onAdd={() => setLearnerModal({})}
              restrictToLearnerId={effectiveLearnerId}
            />
          ) : screen === "learnerProfile" && selectedLearner ? (
            <LearnerProfile
              learner={selectedLearner}
              qualifications={qualifications}
              enrolments={enrolments}
              progress={progress}
              perms={perms}
              onBack={() => setScreen("learners")}
              onEditLearner={() => setLearnerModal(selectedLearner)}
              onDeleteLearner={() => setConfirmDialog({
                message: `Remove ${selectedLearner.firstName} ${selectedLearner.lastName} and their enrolments? This can't be undone.`,
                confirmLabel: "Remove learner",
                onConfirm: () => { deleteLearner(selectedLearner.id); setConfirmDialog(null); },
              })}
              onAddEnrolment={() => setEnrolModal({ initial: null, learnerId: selectedLearner.id })}
              onEditEnrolment={(e) => setEnrolModal({ initial: e, learnerId: selectedLearner.id })}
              onEditProgress={(enrolment, moduleId) => {
                const qualification = qualifications.find((q) => q.id === enrolment.qualificationId);
                const module = qualification && qualification.modules.find((m) => m.id === moduleId);
                if (!module) return;
                setProgressModal({ enrolment, module, existing: progressFor(progress, enrolment.id, moduleId) });
              }}
            />
          ) : screen === "qualifications" ? (
            <QualificationsScreen
              qualifications={qualifications}
              enrolments={enrolments}
              perms={perms}
              onAdd={() => setQualModal({})}
              onEdit={(q) => setQualModal(q)}
            />
          ) : screen === "reports" ? (
            <ReportsScreen learners={learners} qualifications={qualifications} enrolments={enrolments} progress={progress} perms={perms} onReset={() => setConfirmDialog({
              message: "Clear all data and reload the sample dataset? This can't be undone.",
              confirmLabel: "Clear all data",
              onConfirm: () => { resetAll(); setConfirmDialog(null); },
            })} />
          ) : screen === "users" && perms.manageUsers ? (
            <UsersScreen
              users={users}
              learners={learners}
              currentUser={currentUser}
              onAdd={() => setUserModal({})}
              onEdit={(u) => setUserModal(u)}
              onDelete={(u) => setConfirmDialog({
                message: `Remove the login for ${u.displayName}? They won't be able to sign in anymore.`,
                confirmLabel: "Remove login",
                onConfirm: () => { deleteUser(u); setConfirmDialog(null); },
              })}
            />
          ) : null}
        </div>
      </div>

      {learnerModal !== null && (
        <LearnerFormModal
          initial={learnerModal.id ? learnerModal : null}
          onSave={saveLearner}
          onClose={() => setLearnerModal(null)}
        />
      )}
      {qualModal !== null && (
        <QualificationFormModal
          initial={qualModal.id ? qualModal : null}
          onSave={saveQualification}
          onClose={() => setQualModal(null)}
        />
      )}
      {enrolModal !== null && (
        <EnrolmentFormModal
          initial={enrolModal.initial}
          learnerId={enrolModal.learnerId}
          qualifications={qualifications}
          onSave={saveEnrolment}
          onClose={() => setEnrolModal(null)}
        />
      )}
      {userModal !== null && (
        <UserFormModal
          initial={userModal.id ? userModal : null}
          users={users}
          learners={learners}
          onSave={saveUser}
          onClose={() => setUserModal(null)}
        />
      )}
      {progressModal !== null && (
        <ProgressFormModal
          enrolment={progressModal.enrolment}
          module={progressModal.module}
          existing={progressModal.existing}
          perms={perms}
          onSave={saveProgress}
          onClose={() => setProgressModal(null)}
        />
      )}
      {confirmDialog !== null && (
        <ConfirmDialog
          message={confirmDialog.message}
          confirmLabel={confirmDialog.confirmLabel}
          onConfirm={confirmDialog.onConfirm}
          onCancel={() => setConfirmDialog(null)}
        />
      )}
    </div>
  );
}
