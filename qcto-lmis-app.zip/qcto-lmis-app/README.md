# QCTO LMIS

A standalone version of the QCTO Learner Management Information System,
ready to push to GitHub and host for free on GitHub Pages so you can
share a live link with clients.

## Before you deploy

Open `vite.config.js` and set `base` to match your repo name:

```js
base: "/your-repo-name/",
```

If your repo will be named `qcto-lmis`, the current setting
(`/qcto-lmis/`) is already correct — just rename to match whatever you
actually call the repo.

## 1. Run it locally first (optional but recommended)

```bash
npm install
npm run dev
```

Opens at http://localhost:5173 — sign in with one of the demo logins
shown on the sign-in screen.

## 2. Push to GitHub

```bash
git init
git add .
git commit -m "Initial commit"
git branch -M main
git remote add origin https://github.com/<your-username>/<your-repo-name>.git
git push -u origin main
```

## 3. Turn on GitHub Pages

In your repo on GitHub: **Settings → Pages → Build and deployment →
Source → GitHub Actions**.

That's it — pushing to `main` now automatically builds and deploys the
site (see `.github/workflows/deploy.yml`). Check the **Actions** tab
for progress; once it's green, your site is live at:

```
https://<your-username>.github.io/<your-repo-name>/
```

Every time you push a change to `main`, the site updates automatically
within a minute or two.

## Notes on data

This app stores its data (learners, qualifications, enrolments,
progress, and logins) in the visitor's own browser via `localStorage`
— see `src/main.jsx`. That means:

- No server or database to set up — it just works once deployed.
- Each visitor/browser has their own separate copy of the data. If you
  add a learner on your laptop, a client opening the link on their own
  computer won't see it — they'll see the original seeded demo data.
- Clearing browser data (or using a private/incognito window) resets
  the app back to the seed data.

This is fine for demoing the app to clients. If you later want
everyone who visits the link to see the *same*, shared, always-current
data (e.g. real learners logging real progress), you'd need a real
backend and database behind it — happy to help scope that when you're
ready.

## Demo logins

Shown on the sign-in screen itself ("Show demo logins"), or manage
them under **Users** once signed in as Admin.
