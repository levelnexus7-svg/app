import { defineConfig } from "vite";
import react from "@vitejs/plugin-react";

// IMPORTANT: set `base` to "/<your-repo-name>/" before deploying to GitHub Pages.
// e.g. if your repo is github.com/yourname/qcto-lmis, use base: "/qcto-lmis/"
// If you deploy to Netlify/Vercel instead, leave base as "/".
export default defineConfig({
  plugins: [react()],
  base: "/qcto-lmis/",
});
